# :gear: Macros EasyUO :gear:

Repositorio de macros escritas en `EasyUO` para el servidor de [Ultima Alianza](https://ultima-alianza.com/)

![image text](https://i.imgur.com/oKMjDJ6.png)
